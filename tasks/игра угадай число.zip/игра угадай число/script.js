   var number = Math.floor(Math.random() * 20) + 1;
   var attempts = 0;

   function play(){
    var one = document.getElementById("one").value;
    var result = document.getElementById("result");
    
    attempts++;

   if(one < number){
    result.textContent = "Ууупс! Загаданное число больше введенного!";
   }
   else if(one > number){
    result.textContent = "Ууупс! Загаданное число меньше введенного!";
   }
   else {
    result.textContent = "Поздравляем! Вы угадали число!";
    result.textContent += " Количество попыток: " + attempts;
    }
}
